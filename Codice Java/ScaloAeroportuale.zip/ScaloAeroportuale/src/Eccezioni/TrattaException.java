package Eccezioni;

public class TrattaException extends Exception {

	public TrattaException(String errore) {
		
		super(errore);
		
	}
	
}
