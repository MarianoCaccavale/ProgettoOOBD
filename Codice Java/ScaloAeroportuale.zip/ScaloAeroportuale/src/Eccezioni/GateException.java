package Eccezioni;

public class GateException extends Exception {

	public GateException(String errore) {
		
		super(errore);
		
	}
	
	
}
