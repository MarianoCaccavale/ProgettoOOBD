package Eccezioni;

public class ClientiException extends Exception {

	public ClientiException(String errore) {
		
		super(errore);
		
	}
	
}
