package Eccezioni;

public class SlotImbarcoException extends Exception {

	public SlotImbarcoException(String errore) {
		
		super(errore);
		
	}
	
}
