package Eccezioni;


public class VoloException extends Exception {

	public VoloException(String errore) {
		
		super(errore);
		
	}
	
}