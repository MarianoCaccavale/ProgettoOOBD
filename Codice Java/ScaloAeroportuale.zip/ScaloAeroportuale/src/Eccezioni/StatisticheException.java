package Eccezioni;

public class StatisticheException extends Exception {

	public StatisticheException(String errore) {
		
		super(errore);
		
	}
	
}
