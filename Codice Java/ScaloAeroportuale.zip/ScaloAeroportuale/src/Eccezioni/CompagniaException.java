package Eccezioni;

public class CompagniaException extends Exception {

	public CompagniaException(String errore) {
		
		super(errore);
		
	}
	
}
